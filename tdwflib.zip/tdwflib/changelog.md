# Changelog

The log started with version 1.1.0. 

## Version 1.1.0

* A time vector was added for more user-friendly use the module during ADC acquisition
* Read the timestamp via the `SDK` function `FDwfAnalogInStatusTime`
* Renamed the function `.record()` to `.sampleXL()`
* Added `_` for reserved properties
